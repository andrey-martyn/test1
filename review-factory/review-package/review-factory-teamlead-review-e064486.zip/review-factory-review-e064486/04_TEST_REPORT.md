# Отчёт локальных проверок

Проверяемая версия: `e064486728f0a63133c0e8ab03006dba6a9abd9f`. Команды выполнялись **из экспортированной папки source/**, а не из изменяемого рабочего дерева.

Результат: **22 успешных запуска; 517 выполненных assertions**, включая повтор одного набора на PHP 7.3 и 8.2. Это число выполнений, а не количество независимых требований.
Проверка синтаксиса PHP 7.3 охватывает **35 файлов**.

| Скрипт / сценарий | Assertions PHP 7.3 | Assertions PHP 8.2 | Результат |
|---|---:|---:|---|
| `demo.php` | 23 | 23 | passed |
| `demo_native.php catalog` | 11 | 11 | passed |
| `demo_native.php admin` | 13 | 13 | passed |
| `demo_native.php catalog production` | 3 | 3 | passed |
| `simulation.php` | 61 | 61 | passed |
| `source_requests.php` | 30 | 30 | passed |
| `monitoring.php` | 13 | 13 | passed |
| `core.php` | 41 | 41 | passed |
| `replies.php` | 20 | 20 | passed |
| `deployment.php` | — | 24 | passed |

Браузерные проверки Chromium:

- `demo_browser.py`: 19 проверок на 390/1440 px. Демо-пометки, неизменность buyer-score и JSON-LD, literal-text/XSS, корзина, Ajax-карточки, ошибка API, снятие одобрения, production-host.
- `simulation_browser.py`: 44 проверки на 390/1440 px. Вход, автополя, сохранение, очередь, источники, отдельные и объединённые средние, приватный preview, CSRF.

## Как интерпретировать результат

- `demo_native.php` запускает реальные контроллеры нашего расширения с тестовыми объектами Controller/DB/permissions. Это не полный запуск ядра ocStore и установленной темы.
- Native Twig-файл включён в исходники; его реальный рендер в вашей UniShop2 этими тестами не подтверждён.
- Браузерная витрина использует типовую тестовую HTML-разметку и перехваченный same-origin API. Это проверка JS/DOM-контракта, не скриншот вашего магазина.
- Все данные — синтетические локальные фикстуры. Доступа к клиентским БД, реальным учётным записям и реальному хостингу в прогоне не было.
- Legacy MySQL-интеграционные тесты в данном прогоне не запускались; нагрузочное тестирование и фактическая конфигурация LiteSpeed/UniShop2 не проверялись.

## Доказательства

`evidence/results.json` — машинная сводка, `evidence/logs/` — необработанный stdout/stderr команд.
`evidence/*-runtime.json` — фактические PHP-версии и список расширений, `evidence/screenshots/` — только локальные QA-скриншоты.
`evidence/fixtures/demo-public-payload.json` — пример разрешённого API payload из синтетической фикстуры.

Патчи прошли readonly-проверку `git apply --reverse --check` относительно исходников зафиксированного коммита.

## Минимальный локальный прогон

Из папки `source/`, PHP 8.2 с pdo_sqlite/sqlite3/mbstring:

```bash
php review-factory/php/tests/demo.php
php review-factory/php/tests/demo_native.php catalog
php review-factory/php/tests/demo_native.php admin
php review-factory/php/tests/demo_native.php catalog production
php review-factory/php/tests/simulation.php
php review-factory/php/tests/deployment.php
```

Для parser/monitoring-тестов нужен также DOM/XML. Браузерные тесты требуют Python Playwright и Chromium только на машине разработчика; Python-веб-приложение на хостинге не используется. Тестовые образы при прогоне: lavka-php73-dev (PHP 7.3.33), lavka-php-dev (PHP 8.2.34); это локальные образы среды разработки, не внешние обязательные зависимости модуля.
