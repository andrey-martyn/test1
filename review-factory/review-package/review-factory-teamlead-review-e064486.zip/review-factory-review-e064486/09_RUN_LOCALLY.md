# Локальная проверка без хостинга и настоящей БД

Для основного набора достаточно PHP 8.2 CLI с pdo_sqlite, sqlite3 и mbstring. Тесты сами создают и удаляют свои временные синтетические каталоги.

Из корня распакованного пакета:

```bash
cd source
php review-factory/php/tests/demo.php
php review-factory/php/tests/demo_native.php catalog
php review-factory/php/tests/demo_native.php admin
php review-factory/php/tests/demo_native.php catalog production
php review-factory/php/tests/simulation.php
php review-factory/php/tests/deployment.php
```

Catalog/admin тесты используют тестовые объекты вместо настоящего ядра ocStore. MySQL им не нужен. Для parser/monitoring-тестов необходим также DOM/XML.

## Браузерный демо-тест

На машине разработчика нужны Python, Playwright и Chromium. Например, в отдельном venv установить playwright и его Chromium обычным способом. На хостинг это устанавливать не требуется.

Из корня распакованного пакета:

```bash
review_demo_payload=$(mktemp)
php source/review-factory/php/tests/demo_public_fixture.php > "$review_demo_payload"
RF_DEMO_PAYLOAD="$review_demo_payload" \
RF_TEST_OUTPUT=/tmp/review-factory-demo-proof \
python3 source/review-factory/php/tests/demo_browser.py
```

Скрипт использует перехваченные ответы и тестовую HTML-разметку; не обращается к настоящему магазину. Получаются скриншоты и JSON-итог. Результаты прогона экспортированного снимка уже записаны в evidence/.

Полный сценарий кабинета simulation_browser.py требует локально запущенного php -S, собственного тестового пароля в RF_TEST_ENV_FILE и фикстуры seed.php. Он также включён в source/ и уже выполнен при сборке пакета (см. evidence/results.json).

Точные PHP-версии, расширения, версия Playwright и Chromium записаны в evidence/. Это сведения о среде прогона, не требование копировать её приватные настройки.
