"""Local browser smoke test, using a random disposable login password."""
import json
import atexit
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import httpx
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app as application
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
password=secrets.token_urlsafe(24)
temporary=tempfile.TemporaryDirectory()
directory=Path(temporary.name)
shutil.copy2(ROOT/'data'/'analytics.sqlite3',directory/'analytics.sqlite3')
application.DATA=directory;application.AUTH_FILE=directory/'access.json'
application.set_password(password)
with socket.socket() as listener:
    listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
server=subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--host','127.0.0.1','--port',str(port),'--no-access-log'],cwd=ROOT,env={**os.environ,'ANALYTICS_DATA_DIR':str(directory)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
def cleanup():
    server.terminate();server.wait(timeout=10);temporary.cleanup()
atexit.register(cleanup)
base=f'http://127.0.0.1:{port}'
for attempt in range(100):
    try:
        if httpx.get(base+'/health').status_code==200:break
    except httpx.ConnectError:
        pass
    time.sleep(.1)
else:
    raise RuntimeError('Test server did not start')
out=ROOT/'test-results';out.mkdir(exist_ok=True)
errors=[]
checks=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1536,'height':1000},locale='ru-RU')
    page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(base+'/')
    assert page.url.endswith('/login')
    page.fill('#password',password);page.click('button[type=submit]')
    page.wait_for_selector('.customer-table tbody .identity-name')
    checks.append('password login and weekly customer table')
    page.screenshot(path=str(out/'customers.png'),full_page=True)
    page.screenshot(path=str(out/'customers-preview.png'))
    page.locator('[data-action=customer]').first.click()
    page.wait_for_selector('#drawer .order-detail')
    assert page.locator('#drawer .drawer-name').inner_text().startswith('Покупатель')
    checks.append('customer card and order lines')
    page.click('[data-action=close-dialog]')
    page.locator('.heat.active').first.click();page.wait_for_selector('#drawer .order-detail[open]')
    checks.append('week opens actual orders')
    page.click('[data-action=close-dialog]')
    page.fill('#search','__no_customer__');page.wait_for_timeout(250)
    assert 'не найдены' in page.locator('.customer-table').inner_text()
    page.fill('#search','');page.wait_for_timeout(250)
    with page.expect_download() as info:
        page.click('[data-action=export]')
    info.value.save_as(str(out/'customers.csv'))
    checks.append('search and CSV export')
    for view in ['overview','products','geography','duplicates','settings']:
        page.click('[data-view='+view+']')
        page.wait_for_selector('.panel')
        if view=='geography':
            page.wait_for_selector('#map path.map-region')
            assert page.locator('#map path.map-region').count()==27
            page.screenshot(path=str(out/'geography.png'),full_page=True)
            page.screenshot(path=str(out/'geography-preview.png'))
            page.select_option('#map-mode','europe');page.wait_for_selector('#map svg')
            page.wait_for_timeout(500)
            assert page.locator('#map path.map-region').count()>100
        if view=='products':
            page.screenshot(path=str(out/'products.png'),full_page=True)
            page.screenshot(path=str(out/'products-preview.png'))
            page.select_option('#product-mode','products');assert 'вариантов' in page.locator('main tbody').inner_text()
        if view=='settings':
            page.fill('[name=interval_days]','31');page.click('button[type=submit]')
            page.wait_for_selector('#toast:not(.hidden)')
            page.fill('[name=interval_days]','30');page.click('button[type=submit]')
            page.wait_for_timeout(300)
        checks.append(view+' view')
    page.click('[data-view=customers]')
    page.select_option('#year','2025');page.wait_for_timeout(500)
    assert '2025' in page.locator('.customer-table thead').inner_text()
    page.select_option('#year','2026');page.wait_for_timeout(500)
    page.click('[data-action=show-overdue]')
    assert page.locator('#reminder').input_value()=='overdue'
    assert not page.locator('#period-only').is_checked()
    checks.append('year filter and overdue customer filter')
    page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(out/'mobile.png'),full_page=True)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    checks.append('mobile layout without horizontal page overflow')
    page.set_viewport_size({'width':1536,'height':1000})
    page.click('[data-view=settings]');page.click('#logout');page.wait_for_url('**/login')
    checks.append('logout')
    browser.close()
assert not errors,errors
print(json.dumps({'passed':checks,'javascript_errors':errors},ensure_ascii=False,indent=2))
